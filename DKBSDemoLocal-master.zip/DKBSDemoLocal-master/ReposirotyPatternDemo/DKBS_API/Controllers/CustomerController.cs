﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ReposirotyPatternDemo;

namespace DKBS_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : Controller
    {
        IUnitOfWork _unitOfWork;
        private IMapper _mapper;

        public CustomerController(IUnitOfWork unitOfWork,IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        // GET api/Customer/{name of the customer}
        [HttpGet("{name}",Name ="GetCustomer")]
        public ActionResult<Customer> GetCustomer(string name)
        {
            return _unitOfWork.Customers.Find(c => c.Name.StartsWith(name)).FirstOrDefault();
        }

        // GET api/Customer/{customer}
        // URL need to enter in postman https://localhost:44318/api/customer/customer
        // https://localhost:44318/api/customer is same only added is /customer at end
        // note your port number differs than mention above
        [HttpPost("{Customer}")]
        public ActionResult<IEnumerable<Customer>> CreateCustomer([FromBody] Customer customer)
        {
            // Use this line ModelState Valid 
            // It will help to detect weather the annotations are followed properly or not
            // like Name isRequired field in Customer class, so if let us say somebody will pass null for Name field
            // we dont have to check this property ModelState.IsValid will return false, hence returning 
            // the BadRequest
            if (ModelState.IsValid)
            {
                return BadRequest();
            }

            // This is one check to make sure customer itself is not null
            if (customer == null)
                return BadRequest();

            // checking in the DB
            var checkCustomerIdinDb = _unitOfWork.Customers.Find(c => c.CustomerId == customer.CustomerId).FirstOrDefault();

            // If already exist
            if(checkCustomerIdinDb!=null)
            {
                // throw 
                return BadRequest();
            }

            // Simply creating a new object for Customer
            Customer newlyCreatedCustomer = new Customer() { CustomerId=customer.CustomerId, Name=customer.Name, OrderName=customer.OrderName };           
            var source = newlyCreatedCustomer;

            // This is how you have to use AutoMapper
            // _mapper is a field which is injected through contructor above see
            // I have already configure the same in configure service.
            // In our DKBS project you have to simple inject and create a private field for controller as
            // i did here nothing else.
            // This line of code map all the property of source to destination
            // We have same property name for our model class and dto classes hence not required anything extra
            var destination = _mapper.Map<Customer, CustomerDto>(source);


            _unitOfWork.Customers.Add(newlyCreatedCustomer);
            _unitOfWork.Complete();

            // This will return status code 201 which means resource is created succesfully and will redirect the url in response
            // first parameter is the name of the method which we used for get in this case GetCustomer : this will call that method from here thats why it is called redirecting.
            // second param is the param required by the GetCustomer method, in this case our newly created customer name
            // thired param is the newlycreatedcutomer
            // google it you will understand easily if require more clarification
            return CreatedAtRoute("GetCustomer", new { name = newlyCreatedCustomer.Name }, newlyCreatedCustomer);
        }


    }
}