﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReposirotyPatternDemo
{
    public class Partner
    {
        public int PartnerId { get; set; }
        public string PartnerName { get; set; }
        public int ZipCode { get; set; }
    }
}
