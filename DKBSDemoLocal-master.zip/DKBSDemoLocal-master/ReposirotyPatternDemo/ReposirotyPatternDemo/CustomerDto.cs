﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReposirotyPatternDemo
{
    public class CustomerDto
    {
        public ulong CustomerId { get; set; }
        public string Name { get; set; }
        public string OrderName { get; set; }

    }
}
