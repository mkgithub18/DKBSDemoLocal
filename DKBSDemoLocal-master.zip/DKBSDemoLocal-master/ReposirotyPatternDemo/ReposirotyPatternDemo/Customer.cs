﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace ReposirotyPatternDemo
{
    public class Customer
    {
        public ulong CustomerId { get; set; }

        [Required]
        public string Name { get; set; }

        [MaxLength(10)]
        public string OrderName { get; set; }
    }
}
