﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DKBS.Entities
{
    public class Partner
    {
        public long Id { get; set; }
        public string CompanyName { get; set; }
    }
}
