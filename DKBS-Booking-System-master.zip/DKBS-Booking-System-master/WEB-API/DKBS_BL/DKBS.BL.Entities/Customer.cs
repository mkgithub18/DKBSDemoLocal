﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DKBS.Entities
{
    public class Customer
    {
        public long Id { get; set; }
        public string CustomerName { get; set; }
    }
}
