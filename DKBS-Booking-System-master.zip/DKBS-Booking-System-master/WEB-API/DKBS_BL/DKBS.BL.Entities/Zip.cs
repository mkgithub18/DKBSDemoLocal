﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DKBS.Entities
{
    public class Zip
    {
        public long Id { get; set; }
        public int ZipCode { get; set; }
    }
}
