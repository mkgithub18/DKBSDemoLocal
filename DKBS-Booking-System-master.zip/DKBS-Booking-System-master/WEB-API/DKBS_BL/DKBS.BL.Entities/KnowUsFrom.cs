﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DKBS.Entities
{
    public class KnowUsFrom
    {
        public long Id { get; set; }
        public string SocialMediaName { get; set; }
    }
}
