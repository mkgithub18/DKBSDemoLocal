import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-composeemail',
  templateUrl: './composeemail.component.html',
  styleUrls: ['./composeemail.component.css']
})
export class ComposeemailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
