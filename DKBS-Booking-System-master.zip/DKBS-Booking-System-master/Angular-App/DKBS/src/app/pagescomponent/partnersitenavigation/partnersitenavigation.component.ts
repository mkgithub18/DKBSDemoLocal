import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-partnersitenavigation',
  templateUrl: './partnersitenavigation.component.html',
  styleUrls: ['./partnersitenavigation.component.css']
})
export class PartnersitenavigationComponent implements OnInit {
  submenu1: boolean;
  submenu2: boolean;
  submenu3: boolean;
  submenu4: boolean;
  constructor() { }

  ngOnInit() {
  }

}
