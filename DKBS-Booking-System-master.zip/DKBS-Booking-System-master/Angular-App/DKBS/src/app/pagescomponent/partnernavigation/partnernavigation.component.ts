import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-partnernavigation',
  templateUrl: './partnernavigation.component.html',
  styleUrls: ['./partnernavigation.component.css']
})
export class PartnernavigationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
