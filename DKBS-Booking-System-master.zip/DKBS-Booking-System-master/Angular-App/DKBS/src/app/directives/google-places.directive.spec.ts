import { GooglePlacesDirective } from './google-places.directive';

describe('GooglePlacesDirective', () => {
  it('should create an instance', () => {
    const directive = new GooglePlacesDirective();
    expect(directive).toBeTruthy();
  });
});
