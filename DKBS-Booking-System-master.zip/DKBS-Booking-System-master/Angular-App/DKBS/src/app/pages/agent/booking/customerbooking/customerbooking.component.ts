import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerbooking',
  templateUrl: './customerbooking.component.html',
  styleUrls: ['./customerbooking.component.css']
})
export class CustomerbookingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
