import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-awaiting-dkbs',
  templateUrl: './awaiting-dkbs.component.html',
  styleUrls: ['./awaiting-dkbs.component.css']
})
export class AwaitingDKBSComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
