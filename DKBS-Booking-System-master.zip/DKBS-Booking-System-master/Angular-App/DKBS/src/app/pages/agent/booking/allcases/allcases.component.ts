import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allcases',
  templateUrl: './allcases.component.html',
  styleUrls: ['./allcases.component.css']
})
export class AllcasesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
