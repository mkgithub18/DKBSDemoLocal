import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-awaitingeconomy',
  templateUrl: './awaitingeconomy.component.html',
  styleUrls: ['./awaitingeconomy.component.css']
})
export class AwaitingeconomyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
