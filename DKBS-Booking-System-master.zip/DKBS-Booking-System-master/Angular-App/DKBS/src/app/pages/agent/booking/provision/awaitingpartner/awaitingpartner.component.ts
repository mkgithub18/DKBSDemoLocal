import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-awaitingpartner',
  templateUrl: './awaitingpartner.component.html',
  styleUrls: ['./awaitingpartner.component.css']
})
export class AwaitingpartnerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
