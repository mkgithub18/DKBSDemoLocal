import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-centerinnumbers',
  templateUrl: './centerinnumbers.component.html',
  styleUrls: ['./centerinnumbers.component.css']
})
export class CenterinnumbersComponent implements OnInit {
  selectedValueContactPerson:any;
  ContactPerson:any;
  constructor() { }

  ngOnInit() {
  }

}
