import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-centerpremise',
  templateUrl: './centerpremise.component.html',
  styleUrls: ['./centerpremise.component.css']
})
export class CenterpremiseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
