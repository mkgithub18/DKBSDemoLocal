import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-partnerlistsite',
  templateUrl: './partnerlistsite.component.html',
  styleUrls: ['./partnerlistsite.component.css']
})
export class PartnerlistsiteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
