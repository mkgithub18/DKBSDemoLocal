import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-allpartners',
  templateUrl: './allpartners.component.html',
  styleUrls: ['./allpartners.component.css']
})
export class AllPartnersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
