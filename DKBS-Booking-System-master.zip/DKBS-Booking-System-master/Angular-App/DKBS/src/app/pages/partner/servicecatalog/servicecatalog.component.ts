import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servicecatalog',
  templateUrl: './servicecatalog.component.html',
  styleUrls: ['./servicecatalog.component.css']
})
export class ServicecatalogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
