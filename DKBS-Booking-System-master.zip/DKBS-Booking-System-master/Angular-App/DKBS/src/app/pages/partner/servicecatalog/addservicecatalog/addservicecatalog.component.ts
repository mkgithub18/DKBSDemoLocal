import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addservicecatalog',
  templateUrl: './addservicecatalog.component.html',
  styleUrls: ['./addservicecatalog.component.css']
})
export class AddservicecatalogComponent implements OnInit {
  selectedwallet:any;
  constructor() { }

  ngOnInit() {
  }

}
