import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-partnercases',
  templateUrl: './partnercases.component.html',
  styleUrls: ['./partnercases.component.css']
})
export class PartnercasesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
