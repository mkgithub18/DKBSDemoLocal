import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-couserpackageprice',
  templateUrl: './couserpackageprice.component.html',
  styleUrls: ['./couserpackageprice.component.css']
})
export class CouserpackagepriceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
