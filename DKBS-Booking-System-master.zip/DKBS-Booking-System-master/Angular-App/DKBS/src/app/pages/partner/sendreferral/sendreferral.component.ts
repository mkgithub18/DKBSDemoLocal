import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sendreferral',
  templateUrl: './sendreferral.component.html',
  styleUrls: ['./sendreferral.component.css']
})
export class SendreferralComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
