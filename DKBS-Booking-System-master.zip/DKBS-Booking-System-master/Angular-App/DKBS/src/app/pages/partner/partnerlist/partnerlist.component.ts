import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-partnerlist',
  templateUrl: './partnerlist.component.html',
  styleUrls: ['./partnerlist.component.css']
})
export class PartnerlistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
