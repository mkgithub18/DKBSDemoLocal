import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-centerdescription',
  templateUrl: './centerdescription.component.html',
  styleUrls: ['./centerdescription.component.css']
})
export class CenterdescriptionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
