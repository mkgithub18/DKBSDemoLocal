﻿CREATE TABLE [dbo].[NewsTitle]
(
	[NewsTitle_Id] INT NOT NULL PRIMARY KEY
)
