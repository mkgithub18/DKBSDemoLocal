﻿using System;

namespace DKBS.DTO
{
    public class RegionDTO
    {
        public int RegionId { get; set; }
        public string Name { get; set; }
       
    }
}
